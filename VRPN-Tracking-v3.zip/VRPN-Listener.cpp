//== 
//== VRPN Sample Application ==--
//==
//== This application listens for a rigid body named 'Tracker' on the local machine
//== and displays it's position and orientation.
//==
//== You'll also need to download the VRPN distribution files.
//==

//== Includes ==--

#include "vrpn_Connection.h" // Missing this file?  Get the latest VRPN distro at
#include "vrpn_Tracker.h"    //    ftp://ftp.cs.unc.edu/pub/packages/GRIP/vrpn

#include "conio.h"           // for kbhit()

//== Callback prototype ==--

void VRPN_CALLBACK handle_pos (void *, const vrpn_TRACKERCB t);

//== Main entry point ==--

int main(int argc, char* argv[])
{
    vrpn_Connection *connection;

    char connectionName[128];
    int  port = 3883;

    sprintf(connectionName,"localhost:%d", port);
        
    connection = vrpn_get_connection_by_name(connectionName);
    
    vrpn_Tracker_Remote *tracker = new vrpn_Tracker_Remote("Tracker", connection);

  	tracker->register_change_handler(NULL, handle_pos);


    while(!kbhit())
    {
		tracker->mainloop();
		connection->mainloop();
        Sleep(5);
    }

	return 0;
}

//== Position/Orientation Callback ==--

void	VRPN_CALLBACK handle_pos (void *, const vrpn_TRACKERCB t)
{
    printf("Tracker Position:(%.4f,%.4f,%.4f) Orientation:(%.2f,%.2f,%.2f,%.2f)\n",
        t.pos[0], t.pos[1], t.pos[2],
        t.quat[0], t.quat[1], t.quat[2], t.quat[3]);
}
